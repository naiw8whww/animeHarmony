import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const playlists = pgTable("playlists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  coverUrl: text("cover_url"),
});

export const tracks = pgTable("tracks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  artist: text("artist"),
  duration: integer("duration"),
  source: text("source").notNull(), // 'local', 'youtube', etc.
  sourceUrl: text("source_url").notNull(),
  coverUrl: text("cover_url"),
});

export const playlistTracks = pgTable("playlist_tracks", {
  id: serial("id").primaryKey(),
  playlistId: integer("playlist_id").references(() => playlists.id),
  trackId: integer("track_id").references(() => tracks.id),
  position: integer("position").notNull(),
});

export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  theme: text("theme").default("dark"),
  visualizerSettings: jsonb("visualizer_settings"),
  particleSettings: jsonb("particle_settings"),
  backgroundSettings: jsonb("background_settings"),
  equalizerSettings: jsonb("equalizer_settings"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPlaylistSchema = createInsertSchema(playlists).pick({
  name: true,
  description: true,
  coverUrl: true,
  userId: true,
});

export const insertTrackSchema = createInsertSchema(tracks).pick({
  title: true,
  artist: true,
  duration: true,
  source: true,
  sourceUrl: true,
  coverUrl: true,
});

export const insertPlaylistTrackSchema = createInsertSchema(playlistTracks).pick({
  playlistId: true,
  trackId: true,
  position: true,
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).pick({
  userId: true,
  theme: true,
  visualizerSettings: true,
  particleSettings: true,
  backgroundSettings: true,
  equalizerSettings: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertPlaylist = z.infer<typeof insertPlaylistSchema>;
export type InsertTrack = z.infer<typeof insertTrackSchema>;
export type InsertPlaylistTrack = z.infer<typeof insertPlaylistTrackSchema>;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;

export type User = typeof users.$inferSelect;
export type Playlist = typeof playlists.$inferSelect;
export type Track = typeof tracks.$inferSelect;
export type PlaylistTrack = typeof playlistTracks.$inferSelect;
export type UserPreferences = typeof userPreferences.$inferSelect;

// Visualization types
export const visualizerTypes = ["bars", "circular", "wave"] as const;
export type VisualizerType = typeof visualizerTypes[number];

export const colorStyles = ["gradient", "spectrum", "solid"] as const;
export type ColorStyle = typeof colorStyles[number];

export const particleTypes = ["fireflies", "snow", "musicReactive"] as const;
export type ParticleType = typeof particleTypes[number];

export const backgroundTypes = ["image", "color", "gradient"] as const;
export type BackgroundType = typeof backgroundTypes[number];

export const PRESET_BACKGROUNDS = [
  {
    id: 1,
    name: "Anime Night Sky",
    url: "https://images.unsplash.com/photo-1573455494060-c5595004fb6c?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
  },
  {
    id: 2,
    name: "Cherry Blossoms",
    url: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
  },
  {
    id: 3,
    name: "Neon City",
    url: "https://images.unsplash.com/photo-1578632767115-351597cf2477?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
  },
  {
    id: 4,
    name: "Forest Scene",
    url: "https://images.unsplash.com/photo-1552083375-1447ce886485?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
  },
];

export const DEFAULT_VISUALIZER_SETTINGS = {
  type: "bars" as VisualizerType,
  sensitivity: 75,
  barCount: 64,
  animationSpeed: 50,
  colorStyle: "gradient" as ColorStyle,
  colorIntensity: 80,
  glowEffect: true,
  edgeSmoothing: true,
  mirrorEffect: false,
  reactiveBackground: true,
  beatDetection: true,
  frequencyResponse: 30,
};

export const DEFAULT_PARTICLE_SETTINGS = {
  type: "fireflies" as ParticleType,
  density: 50,
  size: 50,
  speed: 50,
  enabled: true,
};

export const DEFAULT_BACKGROUND_SETTINGS = {
  type: "image" as BackgroundType,
  imageUrl: PRESET_BACKGROUNDS[0].url,
  color: "#121212",
  opacity: 20,
  blur: 0,
};

export const DEFAULT_EQUALIZER_SETTINGS = {
  bands: [
    { frequency: "32Hz", gain: 60 },
    { frequency: "64Hz", gain: 70 },
    { frequency: "125Hz", gain: 80 },
    { frequency: "250Hz", gain: 65 },
    { frequency: "500Hz", gain: 50 },
    { frequency: "1kHz", gain: 45 },
    { frequency: "2kHz", gain: 55 },
    { frequency: "4kHz", gain: 60 },
    { frequency: "8kHz", gain: 65 },
    { frequency: "16kHz", gain: 55 },
  ],
  presetName: "Default",
};
