import {
  User,
  InsertUser,
  Playlist,
  InsertPlaylist,
  Track,
  InsertTrack,
  PlaylistTrack,
  InsertPlaylistTrack,
  UserPreferences,
  InsertUserPreferences,
  DEFAULT_VISUALIZER_SETTINGS,
  DEFAULT_PARTICLE_SETTINGS,
  DEFAULT_BACKGROUND_SETTINGS,
  DEFAULT_EQUALIZER_SETTINGS,
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Playlists
  getPlaylists(userId?: number): Promise<Playlist[]>;
  getPlaylist(id: number): Promise<Playlist | undefined>;
  createPlaylist(playlist: InsertPlaylist): Promise<Playlist>;
  updatePlaylist(id: number, data: Partial<InsertPlaylist>): Promise<Playlist | undefined>;
  deletePlaylist(id: number): Promise<boolean>;

  // Tracks
  getTrack(id: number): Promise<Track | undefined>;
  createTrack(track: InsertTrack): Promise<Track>;
  updateTrack(id: number, data: Partial<InsertTrack>): Promise<Track | undefined>;
  deleteTrack(id: number): Promise<boolean>;
  searchTracks(query: string): Promise<Track[]>;

  // Playlist Tracks
  getPlaylistTracks(playlistId: number): Promise<(PlaylistTrack & Track)[]>;
  addTrackToPlaylist(playlistTrack: InsertPlaylistTrack): Promise<PlaylistTrack>;
  removeTrackFromPlaylist(playlistId: number, trackId: number): Promise<boolean>;
  reorderPlaylistTrack(playlistId: number, trackId: number, newPosition: number): Promise<boolean>;

  // User Preferences
  getUserPreferences(userId: number): Promise<UserPreferences | undefined>;
  saveUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private playlists: Map<number, Playlist>;
  private tracks: Map<number, Track>;
  private playlistTracks: Map<number, PlaylistTrack>;
  private userPreferences: Map<number, UserPreferences>;
  
  private userIdCounter: number;
  private playlistIdCounter: number;
  private trackIdCounter: number;
  private playlistTrackIdCounter: number;
  private userPreferencesIdCounter: number;

  constructor() {
    this.users = new Map();
    this.playlists = new Map();
    this.tracks = new Map();
    this.playlistTracks = new Map();
    this.userPreferences = new Map();
    
    this.userIdCounter = 1;
    this.playlistIdCounter = 1;
    this.trackIdCounter = 1;
    this.playlistTrackIdCounter = 1;
    this.userPreferencesIdCounter = 1;
    
    // Initialize with some demo data
    this.seedData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Playlist methods
  async getPlaylists(userId?: number): Promise<Playlist[]> {
    let playlists = Array.from(this.playlists.values());
    if (userId) {
      playlists = playlists.filter(playlist => playlist.userId === userId);
    }
    return playlists;
  }

  async getPlaylist(id: number): Promise<Playlist | undefined> {
    return this.playlists.get(id);
  }

  async createPlaylist(playlist: InsertPlaylist): Promise<Playlist> {
    const id = this.playlistIdCounter++;
    const newPlaylist: Playlist = { ...playlist, id };
    this.playlists.set(id, newPlaylist);
    return newPlaylist;
  }

  async updatePlaylist(id: number, data: Partial<InsertPlaylist>): Promise<Playlist | undefined> {
    const playlist = this.playlists.get(id);
    if (!playlist) return undefined;
    
    const updatedPlaylist = { ...playlist, ...data };
    this.playlists.set(id, updatedPlaylist);
    return updatedPlaylist;
  }

  async deletePlaylist(id: number): Promise<boolean> {
    // Remove playlist tracks first
    const playlistTrackIds = Array.from(this.playlistTracks.values())
      .filter(pt => pt.playlistId === id)
      .map(pt => pt.id);
    
    for (const ptId of playlistTrackIds) {
      this.playlistTracks.delete(ptId);
    }
    
    return this.playlists.delete(id);
  }

  // Track methods
  async getTrack(id: number): Promise<Track | undefined> {
    return this.tracks.get(id);
  }

  async createTrack(track: InsertTrack): Promise<Track> {
    const id = this.trackIdCounter++;
    const newTrack: Track = { ...track, id };
    this.tracks.set(id, newTrack);
    return newTrack;
  }

  async updateTrack(id: number, data: Partial<InsertTrack>): Promise<Track | undefined> {
    const track = this.tracks.get(id);
    if (!track) return undefined;
    
    const updatedTrack = { ...track, ...data };
    this.tracks.set(id, updatedTrack);
    return updatedTrack;
  }

  async deleteTrack(id: number): Promise<boolean> {
    // Remove from playlists
    const playlistTrackIds = Array.from(this.playlistTracks.values())
      .filter(pt => pt.trackId === id)
      .map(pt => pt.id);
    
    for (const ptId of playlistTrackIds) {
      this.playlistTracks.delete(ptId);
    }
    
    return this.tracks.delete(id);
  }

  async searchTracks(query: string): Promise<Track[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.tracks.values()).filter(
      track => 
        track.title.toLowerCase().includes(lowercaseQuery) ||
        (track.artist && track.artist.toLowerCase().includes(lowercaseQuery))
    );
  }

  // Playlist Track methods
  async getPlaylistTracks(playlistId: number): Promise<(PlaylistTrack & Track)[]> {
    const playlistTracksArr = Array.from(this.playlistTracks.values())
      .filter(pt => pt.playlistId === playlistId)
      .sort((a, b) => a.position - b.position);
    
    return playlistTracksArr.map(pt => {
      const track = this.tracks.get(pt.trackId);
      if (!track) throw new Error(`Track ${pt.trackId} not found`);
      return { ...pt, ...track };
    });
  }

  async addTrackToPlaylist(playlistTrack: InsertPlaylistTrack): Promise<PlaylistTrack> {
    const id = this.playlistTrackIdCounter++;
    const newPlaylistTrack: PlaylistTrack = { ...playlistTrack, id };
    this.playlistTracks.set(id, newPlaylistTrack);
    return newPlaylistTrack;
  }

  async removeTrackFromPlaylist(playlistId: number, trackId: number): Promise<boolean> {
    const playlistTrack = Array.from(this.playlistTracks.values())
      .find(pt => pt.playlistId === playlistId && pt.trackId === trackId);
    
    if (!playlistTrack) return false;
    
    return this.playlistTracks.delete(playlistTrack.id);
  }

  async reorderPlaylistTrack(playlistId: number, trackId: number, newPosition: number): Promise<boolean> {
    // Get all playlist tracks
    const playlistTracksArr = Array.from(this.playlistTracks.values())
      .filter(pt => pt.playlistId === playlistId)
      .sort((a, b) => a.position - b.position);
    
    const trackToMove = playlistTracksArr.find(pt => pt.trackId === trackId);
    if (!trackToMove) return false;
    
    // Update positions
    const oldPosition = trackToMove.position;
    if (oldPosition < newPosition) {
      // Moving down
      for (const pt of playlistTracksArr) {
        if (pt.position > oldPosition && pt.position <= newPosition) {
          pt.position--;
          this.playlistTracks.set(pt.id, pt);
        }
      }
    } else if (oldPosition > newPosition) {
      // Moving up
      for (const pt of playlistTracksArr) {
        if (pt.position >= newPosition && pt.position < oldPosition) {
          pt.position++;
          this.playlistTracks.set(pt.id, pt);
        }
      }
    } else {
      // Same position, no change needed
      return true;
    }
    
    // Update the track's position
    trackToMove.position = newPosition;
    this.playlistTracks.set(trackToMove.id, trackToMove);
    
    return true;
  }

  // User Preferences methods
  async getUserPreferences(userId: number): Promise<UserPreferences | undefined> {
    return Array.from(this.userPreferences.values())
      .find(pref => pref.userId === userId);
  }

  async saveUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences> {
    // Check if preferences already exist
    const existingPreferences = await this.getUserPreferences(preferences.userId);
    
    if (existingPreferences) {
      // Update existing
      const updatedPreferences = { ...existingPreferences, ...preferences };
      this.userPreferences.set(existingPreferences.id, updatedPreferences);
      return updatedPreferences;
    } else {
      // Create new
      const id = this.userPreferencesIdCounter++;
      const newPreferences: UserPreferences = { ...preferences, id };
      this.userPreferences.set(id, newPreferences);
      return newPreferences;
    }
  }

  // Seed with demo data
  private seedData() {
    // Create a demo user
    const demoUser: User = {
      id: this.userIdCounter++,
      username: 'demo',
      password: 'demo123'
    };
    this.users.set(demoUser.id, demoUser);

    // Create some demo tracks
    const demoTracks: Track[] = [
      {
        id: this.trackIdCounter++,
        title: 'Lofi Beats to Relax/Study to',
        artist: 'Anime Lofi Collection',
        duration: 332, // 5:32
        source: 'youtube',
        sourceUrl: 'https://www.youtube.com/watch?v=5qap5aO4i9A',
        coverUrl: 'https://images.unsplash.com/photo-1603489889721-b1f8c950bd8d',
      },
      {
        id: this.trackIdCounter++,
        title: 'Anime OST Collection',
        artist: 'Various Artists',
        duration: 202, // 3:22
        source: 'youtube',
        sourceUrl: 'https://www.youtube.com/watch?v=NjTT5_RSkw4',
        coverUrl: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f',
      },
      {
        id: this.trackIdCounter++,
        title: 'Sleep Ambient Sounds',
        artist: 'Relaxing Music',
        duration: 485, // 8:05
        source: 'youtube',
        sourceUrl: 'https://www.youtube.com/watch?v=9QneqUhCVtU',
        coverUrl: 'https://images.unsplash.com/photo-1549880338-65ddcdfd017b',
      },
    ];

    for (const track of demoTracks) {
      this.tracks.set(track.id, track);
    }

    // Create some demo playlists
    const demoPlaylists: Playlist[] = [
      {
        id: this.playlistIdCounter++,
        userId: demoUser.id,
        name: 'Lofi Study Beat',
        description: '32 tracks • 2h 15m',
        coverUrl: 'https://images.unsplash.com/photo-1565098772267-60af42b81ef2',
      },
      {
        id: this.playlistIdCounter++,
        userId: demoUser.id,
        name: 'Anime OST Collection',
        description: '48 tracks • 3h 22m',
        coverUrl: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f',
      },
      {
        id: this.playlistIdCounter++,
        userId: demoUser.id,
        name: 'Sleep Ambient Sounds',
        description: '15 tracks • 8h 05m',
        coverUrl: 'https://images.unsplash.com/photo-1549880338-65ddcdfd017b',
      },
    ];

    for (const playlist of demoPlaylists) {
      this.playlists.set(playlist.id, playlist);
    }

    // Add tracks to playlists
    this.addTrackToPlaylist({
      playlistId: demoPlaylists[0].id,
      trackId: demoTracks[0].id,
      position: 0,
    });

    this.addTrackToPlaylist({
      playlistId: demoPlaylists[1].id,
      trackId: demoTracks[1].id,
      position: 0,
    });

    this.addTrackToPlaylist({
      playlistId: demoPlaylists[2].id,
      trackId: demoTracks[2].id,
      position: 0,
    });

    // Create default user preferences
    this.saveUserPreferences({
      userId: demoUser.id,
      theme: 'dark',
      visualizerSettings: DEFAULT_VISUALIZER_SETTINGS,
      particleSettings: DEFAULT_PARTICLE_SETTINGS,
      backgroundSettings: DEFAULT_BACKGROUND_SETTINGS,
      equalizerSettings: DEFAULT_EQUALIZER_SETTINGS,
    });
  }
}

export const storage = new MemStorage();
