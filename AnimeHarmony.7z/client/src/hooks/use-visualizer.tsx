import { create } from 'zustand';
import { DEFAULT_VISUALIZER_SETTINGS } from '@shared/schema';

interface VisualizerState {
  settings: typeof DEFAULT_VISUALIZER_SETTINGS;
  analyserNode: AnalyserNode | null;
  audioData: Uint8Array | null;
  setSettings: (settings: typeof DEFAULT_VISUALIZER_SETTINGS) => void;
  setAnalyserNode: (node: AnalyserNode | null) => void;
  setAudioData: (data: Uint8Array | null) => void;
}

export const useVisualizerStore = create<VisualizerState>((set) => ({
  settings: DEFAULT_VISUALIZER_SETTINGS,
  analyserNode: null,
  audioData: null,
  setSettings: (settings) => set({ settings }),
  setAnalyserNode: (node) => set({ analyserNode: node }),
  setAudioData: (data) => set({ audioData: data }),
}));

// Optional hook for component use
export function useVisualizer() {
  const { 
    settings,
    analyserNode,
    audioData,
    setSettings,
    setAnalyserNode,
    setAudioData
  } = useVisualizerStore();
  
  // Update audio data from the analyzer node
  const updateAudioData = () => {
    if (analyserNode) {
      const dataArray = new Uint8Array(analyserNode.frequencyBinCount);
      analyserNode.getByteFrequencyData(dataArray);
      setAudioData(dataArray);
      requestAnimationFrame(updateAudioData);
    }
  };
  
  return {
    settings,
    analyserNode,
    audioData,
    setSettings,
    setAnalyserNode,
    updateAudioData,
  };
}

export default useVisualizer;
