import { useState, useEffect, useRef } from "react";

interface AudioHookResult {
  audioContext: AudioContext | null;
  analyserNode: AnalyserNode | null;
  audioData: Uint8Array | null;
  setAudioSource: (source: HTMLMediaElement) => void;
}

export function useAudio(): AudioHookResult {
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [analyserNode, setAnalyserNode] = useState<AnalyserNode | null>(null);
  const [audioData, setAudioData] = useState<Uint8Array | null>(null);
  const audioSourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const frameRef = useRef<number | null>(null);
  
  // Initialize audio context
  useEffect(() => {
    // Create audio context on demand to avoid autoplay issues
    const initializeAudioContext = () => {
      try {
        // Browser compatibility for AudioContext
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioContextClass) {
          console.error("AudioContext not supported in this browser");
          return null;
        }
        
        const context = new AudioContextClass();
        const analyser = context.createAnalyser();
        
        // Configure analyser
        analyser.fftSize = 256; // Must be a power of 2
        analyser.smoothingTimeConstant = 0.8; // 0 - 1, higher = smoother
        
        // Create data array for analyser
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        
        setAudioContext(context);
        setAnalyserNode(analyser);
        setAudioData(dataArray);
        
        return { context, analyser, dataArray };
      } catch (error) {
        console.error("Error initializing audio context:", error);
        return null;
      }
    };
    
    // Don't initialize immediately - wait for user interaction
    return () => {
      // Clean up on unmount
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      
      if (audioContext) {
        audioContext.close();
      }
    };
  }, []);
  
  // Set up audio processing and analyzer
  const setAudioSource = (audioElement: HTMLMediaElement) => {
    if (!audioContext) {
      // Lazy initialization of audio context on first playback
      const audio = initializeAudioContext();
      if (!audio) return;
      
      const { context, analyser, dataArray } = audio;
      
      // Create source node from audio element
      const source = context.createMediaElementSource(audioElement);
      audioSourceRef.current = source;
      
      // Connect audio routing: source -> analyser -> destination (speakers)
      source.connect(analyser);
      analyser.connect(context.destination);
      
      // Start analyzer loop
      updateAnalyzer(analyser, dataArray);
    } else if (!audioSourceRef.current) {
      // AudioContext exists but no source connected yet
      if (analyserNode && audioData) {
        // Create source node from audio element
        const source = audioContext.createMediaElementSource(audioElement);
        audioSourceRef.current = source;
        
        // Connect audio routing: source -> analyser -> destination (speakers)
        source.connect(analyserNode);
        analyserNode.connect(audioContext.destination);
        
        // Start analyzer loop
        updateAnalyzer(analyserNode, audioData);
      }
    }
    // If source already exists, no need to reconnect
  };
  
  // Initialize audio context
  const initializeAudioContext = () => {
    try {
      // Browser compatibility for AudioContext
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) {
        console.error("AudioContext not supported in this browser");
        return null;
      }
      
      const context = new AudioContextClass();
      const analyser = context.createAnalyser();
      
      // Configure analyser
      analyser.fftSize = 256; // Must be a power of 2
      analyser.smoothingTimeConstant = 0.8; // 0 - 1, higher = smoother
      
      // Create data array for analyser
      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      
      setAudioContext(context);
      setAnalyserNode(analyser);
      setAudioData(dataArray);
      
      return { context, analyser, dataArray };
    } catch (error) {
      console.error("Error initializing audio context:", error);
      return null;
    }
  };
  
  // Update analyzer in animation loop
  const updateAnalyzer = (analyser: AnalyserNode, dataArray: Uint8Array) => {
    const updateLoop = () => {
      // Get frequency data
      analyser.getByteFrequencyData(dataArray);
      
      // Copy data to state (important: create a new Uint8Array to trigger re-renders)
      setAudioData(new Uint8Array(dataArray));
      
      // Continue loop
      frameRef.current = requestAnimationFrame(updateLoop);
    };
    
    // Start the loop
    frameRef.current = requestAnimationFrame(updateLoop);
  };
  
  return {
    audioContext,
    analyserNode,
    audioData,
    setAudioSource,
  };
}

export default useAudio;
