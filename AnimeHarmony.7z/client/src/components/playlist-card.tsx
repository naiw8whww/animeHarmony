import { useState } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Playlist, Track } from "@shared/schema";
import { cn } from "@/lib/utils";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PlaylistCardProps {
  playlist: Playlist;
  onPlay?: (playlist: Playlist) => void;
  className?: string;
}

export function PlaylistCard({ 
  playlist, 
  onPlay, 
  className 
}: PlaylistCardProps) {
  const [isHovering, setIsHovering] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const deletePlaylistMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/playlists/${id}`);
      return id;
    },
    onSuccess: (id) => {
      queryClient.invalidateQueries({ queryKey: ['/api/playlists'] });
      toast({
        title: "Playlist deleted",
        description: "The playlist has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete playlist",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  const handlePlay = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onPlay) {
      onPlay(playlist);
    }
  };
  
  const handleDelete = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (confirm("Are you sure you want to delete this playlist?")) {
      deletePlaylistMutation.mutate(playlist.id);
    }
  };
  
  return (
    <Card 
      className={cn(
        "bg-dark-surface/80 backdrop-blur-md rounded-lg overflow-hidden group transition-all border-none shadow-lg relative",
        className
      )}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      <Link href={`/playlist/${playlist.id}`}>
        <a className="block">
          <div className="absolute inset-0 opacity-20 pointer-events-none bg-gradient-to-br from-neon-blue/30 to-neon-pink/30 group-hover:opacity-30 transition-opacity" />
          
          <div className="h-40 relative">
            <img 
              src={playlist.coverUrl} 
              alt={playlist.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark-base to-transparent opacity-70" />
            
            <div 
              className={cn(
                "absolute inset-0 flex items-center justify-center transition-opacity",
                isHovering ? "opacity-100" : "opacity-0"
              )}
            >
              <Button 
                onClick={handlePlay}
                className="bg-neon-pink hover:bg-neon-pink/90 text-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
              </Button>
            </div>
          </div>
          
          <div className="p-4">
            <h3 className="font-semibold mb-1 text-white group-hover:text-neon-pink transition-colors">{playlist.name}</h3>
            <p className="text-white/60 text-sm mb-2">{playlist.description}</p>
            <div className="flex items-center justify-between text-white/60 text-xs">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 18V5l12-2v13" />
                  <circle cx="6" cy="18" r="3" />
                  <circle cx="18" cy="16" r="3" />
                </svg>
                <span>
                  {playlist.description?.split('•')[0]?.trim() || "0 tracks"}
                </span>
              </div>
              
              {isHovering && (
                <Button 
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-white/60 hover:text-white hover:bg-white/10 rounded-full"
                  onClick={handleDelete}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3 6h18" />
                    <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                    <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                  </svg>
                </Button>
              )}
            </div>
          </div>
        </a>
      </Link>
    </Card>
  );
}

export default PlaylistCard;
