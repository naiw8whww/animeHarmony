import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { BackgroundSelector } from "@/components/ui/background-selector";
import { 
  BackgroundType,
  DEFAULT_BACKGROUND_SETTINGS,
  PRESET_BACKGROUNDS
} from "@shared/schema";

interface BackgroundSettingsProps {
  settings: typeof DEFAULT_BACKGROUND_SETTINGS;
  onChange: (settings: typeof DEFAULT_BACKGROUND_SETTINGS) => void;
  onUploadBackground: (file: File) => Promise<string>;
  className?: string;
}

export function BackgroundSettings({
  settings,
  onChange,
  onUploadBackground,
  className
}: BackgroundSettingsProps) {
  const [localSettings, setLocalSettings] = useState(settings);
  
  const updateSettings = (key: keyof typeof settings, value: any) => {
    const newSettings = { ...localSettings, [key]: value };
    setLocalSettings(newSettings);
    onChange(newSettings);
  };
  
  const handleSelectBackground = (imageUrl: string) => {
    updateSettings('type', 'image');
    updateSettings('imageUrl', imageUrl);
  };
  
  const handleUploadBackground = async (file: File) => {
    try {
      const imageUrl = await onUploadBackground(file);
      updateSettings('type', 'image');
      updateSettings('imageUrl', imageUrl);
    } catch (error) {
      console.error("Failed to upload background:", error);
    }
  };
  
  const handleOpacityChange = (opacity: number) => {
    updateSettings('opacity', opacity);
  };
  
  const handleBlurChange = (blur: number) => {
    updateSettings('blur', blur);
  };
  
  const handleBackgroundTypeChange = (type: BackgroundType) => {
    updateSettings('type', type);
  };
  
  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateSettings('color', e.target.value);
  };
  
  return (
    <Card className={cn("bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden", className)}>
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
      <CardContent className="p-6 relative">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-xl font-bold flex items-center text-white">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-neon-blue" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
              <circle cx="8.5" cy="8.5" r="1.5" />
              <polyline points="21 15 16 10 5 21" />
            </svg>
            Background Settings
          </h2>
          
          <BackgroundSelector
            onSelectBackground={handleSelectBackground}
            onUploadBackground={handleUploadBackground}
            onOpacityChange={handleOpacityChange}
            onBlurChange={handleBlurChange}
            opacity={localSettings.opacity}
            blur={localSettings.blur}
            selectedBackground={localSettings.type === 'image' ? localSettings.imageUrl : undefined}
          />
        </div>
        
        <Tabs defaultValue="image" value={localSettings.type} onValueChange={handleBackgroundTypeChange as (value: string) => void}>
          <TabsList className="bg-dark-elevated mb-6">
            <TabsTrigger value="image" className="data-[state=active]:text-neon-blue">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                <circle cx="8.5" cy="8.5" r="1.5" />
                <polyline points="21 15 16 10 5 21" />
              </svg>
              Image
            </TabsTrigger>
            <TabsTrigger value="color" className="data-[state=active]:text-neon-pink">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m9 11 3 3L22 4" />
                <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
              </svg>
              Solid Color
            </TabsTrigger>
            <TabsTrigger value="gradient" className="data-[state=active]:text-neon-orange">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 12H2v4h16" />
                <path d="M22 6H4v4h18" />
                <path d="M14 18H6v4h8" />
              </svg>
              Gradient
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="image" className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {PRESET_BACKGROUNDS.map((bg) => (
                <div 
                  key={bg.id}
                  className={cn(
                    "relative rounded-lg overflow-hidden h-32 cursor-pointer group hover:ring-2",
                    localSettings.imageUrl === bg.url ? 'ring-2 ring-neon-pink' : ''
                  )}
                  onClick={() => handleSelectBackground(bg.url)}
                >
                  <img 
                    src={bg.url} 
                    alt={bg.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-base to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2">
                    <span className="text-white text-sm font-medium">{bg.name}</span>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="space-y-5">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label className="text-sm text-white/70">Background Opacity</Label>
                  <span className="text-sm text-white/70">{localSettings.opacity}%</span>
                </div>
                <Slider
                  defaultValue={[localSettings.opacity]}
                  value={[localSettings.opacity]}
                  max={100}
                  step={1}
                  onValueChange={(value) => handleOpacityChange(value[0])}
                  className="w-full"
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label className="text-sm text-white/70">Blur Effect</Label>
                  <span className="text-sm text-white/70">{localSettings.blur}px</span>
                </div>
                <Slider
                  defaultValue={[localSettings.blur]}
                  value={[localSettings.blur]}
                  max={20}
                  step={1}
                  onValueChange={(value) => handleBlurChange(value[0])}
                  className="w-full"
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="color" className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-sm text-white/70">Background Color</Label>
                <div className="flex gap-3">
                  <div className="w-12 h-12 rounded-md overflow-hidden">
                    <div 
                      className="w-full h-full" 
                      style={{ backgroundColor: localSettings.color }}
                    />
                  </div>
                  <Input
                    type="color"
                    value={localSettings.color}
                    onChange={handleColorChange}
                    className="bg-dark-elevated border-none text-white w-full p-1 h-12"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-5 gap-2">
                <Button
                  type="button"
                  className="w-full h-8 p-0 border-none"
                  style={{ backgroundColor: "#121212" }}
                  onClick={() => updateSettings('color', '#121212')}
                />
                <Button
                  type="button"
                  className="w-full h-8 p-0 border-none"
                  style={{ backgroundColor: "#1E1E1E" }}
                  onClick={() => updateSettings('color', '#1E1E1E')}
                />
                <Button
                  type="button"
                  className="w-full h-8 p-0 border-none"
                  style={{ backgroundColor: "#2D2D2D" }}
                  onClick={() => updateSettings('color', '#2D2D2D')}
                />
                <Button
                  type="button"
                  className="w-full h-8 p-0 border-none"
                  style={{ backgroundColor: "#0F172A" }}
                  onClick={() => updateSettings('color', '#0F172A')}
                />
                <Button
                  type="button"
                  className="w-full h-8 p-0 border-none"
                  style={{ backgroundColor: "#18181B" }}
                  onClick={() => updateSettings('color', '#18181B')}
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="gradient" className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div 
                className="h-32 rounded-lg overflow-hidden cursor-pointer hover:ring-2 ring-neon-blue"
                onClick={() => updateSettings('color', 'linear-gradient(45deg, #9D4EDD, #00FFFF)')}
              >
                <div 
                  className="w-full h-full" 
                  style={{ background: 'linear-gradient(45deg, #9D4EDD, #00FFFF)' }}
                />
              </div>
              <div 
                className="h-32 rounded-lg overflow-hidden cursor-pointer hover:ring-2 ring-neon-blue"
                onClick={() => updateSettings('color', 'linear-gradient(45deg, #FF00FF, #00FFFF)')}
              >
                <div 
                  className="w-full h-full" 
                  style={{ background: 'linear-gradient(45deg, #FF00FF, #00FFFF)' }}
                />
              </div>
              <div 
                className="h-32 rounded-lg overflow-hidden cursor-pointer hover:ring-2 ring-neon-blue"
                onClick={() => updateSettings('color', 'linear-gradient(45deg, #FF9900, #9D4EDD)')}
              >
                <div 
                  className="w-full h-full" 
                  style={{ background: 'linear-gradient(45deg, #FF9900, #9D4EDD)' }}
                />
              </div>
              <div 
                className="h-32 rounded-lg overflow-hidden cursor-pointer hover:ring-2 ring-neon-blue"
                onClick={() => updateSettings('color', 'linear-gradient(to right, #0f0c29, #302b63, #24243e)')}
              >
                <div 
                  className="w-full h-full" 
                  style={{ background: 'linear-gradient(to right, #0f0c29, #302b63, #24243e)' }}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm text-white/70">Gradient Opacity</Label>
              <div className="flex justify-between">
                <span className="text-sm text-white/70">Transparent</span>
                <span className="text-sm text-white/70">Solid</span>
              </div>
              <Slider
                defaultValue={[localSettings.opacity]}
                value={[localSettings.opacity]}
                max={100}
                step={1}
                onValueChange={(value) => handleOpacityChange(value[0])}
                className="w-full"
              />
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

export default BackgroundSettings;
