import { useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

interface WaveformProps {
  audioData: Uint8Array;
  type: "bars" | "circular" | "wave";
  barCount?: number;
  sensitivity?: number;
  colorStyle?: "gradient" | "spectrum" | "solid";
  colorIntensity?: number;
  glowEffect?: boolean;
  mirrorEffect?: boolean;
  className?: string;
}

export function Waveform({
  audioData,
  type = "bars",
  barCount = 64,
  sensitivity = 75,
  colorStyle = "gradient",
  colorIntensity = 80,
  glowEffect = true,
  mirrorEffect = false,
  className,
}: WaveformProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Scale sensitivity from 0-100 to 0.1-3
  const scaledSensitivity = (sensitivity / 100) * 2.9 + 0.1;
  
  // Scale color intensity from 0-100 to 0.2-1
  const scaledColorIntensity = (colorIntensity / 100) * 0.8 + 0.2;

  useEffect(() => {
    if (!canvasRef.current || !audioData) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Adjust canvas size to parent element
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    // Calculate the slice of data to use based on barCount
    const sliceWidth = Math.floor(audioData.length / barCount);
    
    // Draw based on visualization type
    switch(type) {
      case "bars":
        drawBars(ctx, canvas, audioData, sliceWidth, scaledSensitivity, colorStyle, scaledColorIntensity, glowEffect, mirrorEffect);
        break;
      case "circular":
        drawCircular(ctx, canvas, audioData, sliceWidth, scaledSensitivity, colorStyle, scaledColorIntensity, glowEffect);
        break;
      case "wave":
        drawWave(ctx, canvas, audioData, sliceWidth, scaledSensitivity, colorStyle, scaledColorIntensity, glowEffect);
        break;
      default:
        drawBars(ctx, canvas, audioData, sliceWidth, scaledSensitivity, colorStyle, scaledColorIntensity, glowEffect, mirrorEffect);
    }
  }, [audioData, type, barCount, sensitivity, colorStyle, colorIntensity, glowEffect, mirrorEffect]);

  return (
    <canvas 
      ref={canvasRef} 
      className={cn("w-full h-full", className)}
    />
  );
}

function drawBars(
  ctx: CanvasRenderingContext2D, 
  canvas: HTMLCanvasElement, 
  audioData: Uint8Array, 
  sliceWidth: number,
  sensitivity: number,
  colorStyle: string,
  colorIntensity: number,
  glowEffect: boolean,
  mirrorEffect: boolean
) {
  const barWidth = canvas.width / Math.min(audioData.length, sliceWidth * 64);
  const halfHeight = mirrorEffect ? canvas.height / 2 : canvas.height;
  
  for (let i = 0; i < Math.min(audioData.length, sliceWidth * 64); i += sliceWidth) {
    // Get average amplitude for this slice
    let sum = 0;
    for (let j = 0; j < sliceWidth; j++) {
      if (i + j < audioData.length) {
        sum += audioData[i + j];
      }
    }
    const average = sum / sliceWidth;
    
    // Apply sensitivity multiplier
    const barHeight = (average / 255) * halfHeight * sensitivity;
    
    // Calculate x position
    const x = i / sliceWidth * barWidth;
    
    // Set color based on style
    ctx.fillStyle = getColor(i, audioData.length, colorStyle, colorIntensity);
    
    if (glowEffect) {
      ctx.shadowBlur = 15;
      ctx.shadowColor = ctx.fillStyle;
    } else {
      ctx.shadowBlur = 0;
    }
    
    // Draw the bar
    if (mirrorEffect) {
      // Top bar (flipped)
      ctx.fillRect(x, halfHeight - barHeight, barWidth - 1, barHeight);
      // Bottom bar
      ctx.fillRect(x, halfHeight, barWidth - 1, barHeight);
    } else {
      // Single bar from bottom
      ctx.fillRect(x, canvas.height - barHeight, barWidth - 1, barHeight);
    }
  }
}

function drawCircular(
  ctx: CanvasRenderingContext2D, 
  canvas: HTMLCanvasElement, 
  audioData: Uint8Array, 
  sliceWidth: number,
  sensitivity: number,
  colorStyle: string,
  colorIntensity: number,
  glowEffect: boolean
) {
  const centerX = canvas.width / 2;
  const centerY = canvas.height / 2;
  const radius = Math.min(centerX, centerY) * 0.8;
  
  const barCount = Math.floor(audioData.length / sliceWidth);
  const angleStep = (Math.PI * 2) / barCount;
  
  for (let i = 0; i < barCount; i++) {
    // Get average amplitude for this slice
    let sum = 0;
    for (let j = 0; j < sliceWidth; j++) {
      const index = i * sliceWidth + j;
      if (index < audioData.length) {
        sum += audioData[index];
      }
    }
    const average = sum / sliceWidth;
    
    // Apply sensitivity multiplier
    const barHeight = (average / 255) * radius * 0.5 * sensitivity;
    
    // Calculate angle
    const angle = i * angleStep;
    
    // Calculate start and end points
    const innerX = centerX + (radius - barHeight) * Math.cos(angle);
    const innerY = centerY + (radius - barHeight) * Math.sin(angle);
    const outerX = centerX + radius * Math.cos(angle);
    const outerY = centerY + radius * Math.sin(angle);
    
    // Set color based on style
    ctx.strokeStyle = getColor(i, barCount, colorStyle, colorIntensity);
    ctx.lineWidth = 2;
    
    if (glowEffect) {
      ctx.shadowBlur = 15;
      ctx.shadowColor = ctx.strokeStyle;
    } else {
      ctx.shadowBlur = 0;
    }
    
    // Draw the line
    ctx.beginPath();
    ctx.moveTo(innerX, innerY);
    ctx.lineTo(outerX, outerY);
    ctx.stroke();
  }
}

function drawWave(
  ctx: CanvasRenderingContext2D, 
  canvas: HTMLCanvasElement, 
  audioData: Uint8Array, 
  sliceWidth: number,
  sensitivity: number,
  colorStyle: string,
  colorIntensity: number,
  glowEffect: boolean
) {
  ctx.beginPath();
  ctx.moveTo(0, canvas.height / 2);
  
  const points: [number, number][] = [];
  
  for (let i = 0; i < audioData.length; i += sliceWidth) {
    // Get average amplitude for this slice
    let sum = 0;
    for (let j = 0; j < sliceWidth; j++) {
      if (i + j < audioData.length) {
        sum += audioData[i + j];
      }
    }
    const average = sum / sliceWidth;
    
    // Apply sensitivity multiplier
    const normalized = (average / 255) * canvas.height * 0.4 * sensitivity;
    
    // Calculate x position
    const x = (i / audioData.length) * canvas.width;
    const y = (canvas.height / 2) - normalized;
    
    points.push([x, y]);
    ctx.lineTo(x, y);
  }
  
  // Complete the path to the bottom right, bottom left, and back to start
  ctx.lineTo(canvas.width, canvas.height / 2);
  
  // Set gradient fill
  const gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
  if (colorStyle === "gradient") {
    gradient.addColorStop(0, `rgba(0, 255, 255, ${colorIntensity})`);
    gradient.addColorStop(1, `rgba(255, 0, 255, ${colorIntensity})`);
  } else if (colorStyle === "spectrum") {
    gradient.addColorStop(0, `rgba(0, 255, 255, ${colorIntensity})`);
    gradient.addColorStop(0.33, `rgba(255, 0, 255, ${colorIntensity})`);
    gradient.addColorStop(0.66, `rgba(255, 153, 0, ${colorIntensity})`);
    gradient.addColorStop(1, `rgba(0, 255, 255, ${colorIntensity})`);
  } else {
    gradient.addColorStop(0, `rgba(255, 255, 255, ${colorIntensity})`);
    gradient.addColorStop(1, `rgba(255, 255, 255, ${colorIntensity})`);
  }
  
  ctx.fillStyle = gradient;
  
  if (glowEffect) {
    ctx.shadowBlur = 15;
    ctx.shadowColor = 'rgba(0, 255, 255, 0.5)';
  } else {
    ctx.shadowBlur = 0;
  }
  
  ctx.fill();
  
  // Draw path outline
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
  ctx.lineWidth = 2;
  ctx.stroke();
}

function getColor(
  index: number, 
  total: number, 
  style: string, 
  intensity: number
): string {
  if (style === "gradient") {
    const ratio = index / total;
    const r = Math.floor(255 - 255 * ratio);
    const g = Math.floor(255 * (1 - Math.abs(2 * ratio - 1)));
    const b = Math.floor(255 * ratio);
    return `rgba(${r}, ${g}, ${b}, ${intensity})`;
  } else if (style === "spectrum") {
    const hue = (index / total) * 360;
    return `hsla(${hue}, 100%, 50%, ${intensity})`;
  } else {
    return `rgba(255, 255, 255, ${intensity})`;
  }
}

export default Waveform;
