import { useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

interface Particle {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  opacity: number;
  color: string;
  life: number;
  maxLife: number;
}

interface ParticleSystemProps {
  type: "fireflies" | "snow" | "musicReactive";
  density?: number;
  size?: number;
  speed?: number;
  audioData?: Uint8Array;
  className?: string;
}

export function ParticleSystem({
  type = "fireflies",
  density = 50,
  size = 50,
  speed = 50,
  audioData,
  className,
}: ParticleSystemProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  
  // Scale density from 0-100 to 20-200
  const particleCount = Math.floor((density / 100) * 180 + 20);
  
  // Scale size from 0-100 to 2-20
  const particleSize = (size / 100) * 18 + 2;
  
  // Scale speed from 0-100 to 0.5-3
  const particleSpeed = (speed / 100) * 2.5 + 0.5;
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    // Adjust canvas size to parent element
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    // Initialize particles if needed
    if (particlesRef.current.length === 0) {
      initializeParticles(type, particleCount, particleSize, particleSpeed, canvas.width, canvas.height);
    }
    
    // Animation loop
    let animationFrameId: number;
    
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Update and draw particles
      updateParticles(ctx, canvas.width, canvas.height, type, audioData);
      
      animationFrameId = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [type, particleCount, particleSize, particleSpeed, audioData]);
  
  const initializeParticles = (
    type: string, 
    count: number, 
    size: number, 
    speed: number, 
    width: number, 
    height: number
  ) => {
    const particles: Particle[] = [];
    
    for (let i = 0; i < count; i++) {
      if (type === "fireflies") {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          size: Math.random() * size + 2,
          speedX: (Math.random() - 0.5) * speed,
          speedY: (Math.random() - 0.5) * speed,
          opacity: Math.random() * 0.5 + 0.3,
          color: `hsl(${Math.random() * 60 + 180}, 100%, 70%)`,
          life: 0,
          maxLife: Math.random() * 100 + 100
        });
      } else if (type === "snow") {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          size: Math.random() * size + 1,
          speedX: (Math.random() - 0.5) * speed * 0.3,
          speedY: Math.random() * speed + 0.5,
          opacity: Math.random() * 0.3 + 0.7,
          color: "rgb(255, 255, 255)",
          life: 0,
          maxLife: Infinity
        });
      } else if (type === "musicReactive") {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          size: Math.random() * size + 3,
          speedX: (Math.random() - 0.5) * speed * 1.5,
          speedY: (Math.random() - 0.5) * speed * 1.5,
          opacity: Math.random() * 0.5 + 0.5,
          color: `hsl(${Math.random() * 360}, 100%, 70%)`,
          life: 0,
          maxLife: Math.random() * 60 + 40
        });
      }
    }
    
    particlesRef.current = particles;
  };
  
  const updateParticles = (
    ctx: CanvasRenderingContext2D, 
    width: number, 
    height: number, 
    type: string,
    audioData?: Uint8Array
  ) => {
    const particles = particlesRef.current;
    
    // Calculate audio intensity (0-1) if audio data is available
    let audioIntensity = 0;
    if (audioData && audioData.length > 0) {
      let sum = 0;
      for (let i = 0; i < audioData.length; i++) {
        sum += audioData[i];
      }
      audioIntensity = sum / (audioData.length * 255);
    }
    
    // Update and draw each particle
    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      
      if (type === "fireflies") {
        // Pulsing effect
        p.opacity = 0.3 + Math.sin(p.life / 10) * 0.3;
        
        // Slow drift movement
        p.x += p.speedX;
        p.y += p.speedY;
        
        // Periodically change direction
        if (Math.random() < 0.01) {
          p.speedX = (Math.random() - 0.5) * particleSpeed;
          p.speedY = (Math.random() - 0.5) * particleSpeed;
        }
      } else if (type === "snow") {
        // Add a slight wobble
        p.x += p.speedX + Math.sin(p.life / 20) * 0.2;
        p.y += p.speedY;
      } else if (type === "musicReactive") {
        // Speed based on audio intensity
        const speedMultiplier = 1 + audioIntensity * 3;
        p.x += p.speedX * speedMultiplier;
        p.y += p.speedY * speedMultiplier;
        
        // Size and opacity based on audio
        p.size = particleSize * (1 + audioIntensity * 2);
        p.opacity = 0.2 + audioIntensity * 0.8;
      }
      
      // Boundary handling: wrap around
      if (p.x < -p.size) p.x = width + p.size;
      if (p.x > width + p.size) p.x = -p.size;
      if (p.y < -p.size) p.y = height + p.size;
      if (p.y > height + p.size) p.y = -p.size;
      
      // Increment life
      p.life++;
      
      // Reset particle if it exceeds maxLife
      if (p.life > p.maxLife) {
        if (type === "fireflies" || type === "musicReactive") {
          p.x = Math.random() * width;
          p.y = Math.random() * height;
          p.life = 0;
          p.maxLife = Math.random() * 100 + 100;
          
          if (type === "musicReactive") {
            p.color = `hsl(${Math.random() * 360}, 100%, 70%)`;
          }
        }
      }
      
      // Draw particle
      ctx.beginPath();
      ctx.globalAlpha = p.opacity;
      
      // Add glow effect
      ctx.shadowBlur = p.size * 2;
      ctx.shadowColor = p.color;
      
      // Draw a circle or special shape
      if (type === "fireflies" || type === "musicReactive") {
        // Radial gradient for glow effect
        const gradient = ctx.createRadialGradient(
          p.x, p.y, 0,
          p.x, p.y, p.size
        );
        gradient.addColorStop(0, p.color);
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = gradient;
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      } else if (type === "snow") {
        ctx.fillStyle = p.color;
        // Sometimes draw snowflakes, sometimes circles
        if (i % 3 === 0) {
          drawSnowflake(ctx, p.x, p.y, p.size);
        } else {
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        }
      }
      
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.shadowBlur = 0;
    }
  };
  
  const drawSnowflake = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    size: number
  ) => {
    const spikes = 6;
    const rotation = Math.PI / spikes;
    
    ctx.beginPath();
    for (let i = 0; i < spikes * 2; i++) {
      const radius = i % 2 === 0 ? size : size * 0.4;
      const angle = (i * Math.PI) / spikes;
      const pointX = x + Math.cos(angle) * radius;
      const pointY = y + Math.sin(angle) * radius;
      
      if (i === 0) {
        ctx.moveTo(pointX, pointY);
      } else {
        ctx.lineTo(pointX, pointY);
      }
    }
    ctx.closePath();
    ctx.fill();
  };
  
  return (
    <canvas 
      ref={canvasRef} 
      className={cn("w-full h-full absolute inset-0", className)}
    />
  );
}

export default ParticleSystem;
