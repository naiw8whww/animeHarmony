import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { 
  ParticleType, 
  DEFAULT_PARTICLE_SETTINGS 
} from "@shared/schema";

interface ParticleSettingsProps {
  settings: typeof DEFAULT_PARTICLE_SETTINGS;
  onChange: (settings: typeof DEFAULT_PARTICLE_SETTINGS) => void;
  className?: string;
  isPremium?: boolean;
}

export function ParticleSettings({
  settings,
  onChange,
  className,
  isPremium = false,
}: ParticleSettingsProps) {
  const [localSettings, setLocalSettings] = useState(settings);
  
  const updateSettings = (key: keyof typeof settings, value: any) => {
    const newSettings = { ...localSettings, [key]: value };
    setLocalSettings(newSettings);
    onChange(newSettings);
  };
  
  const handleTypeChange = (type: ParticleType) => {
    updateSettings('type', type);
  };
  
  const handleReset = () => {
    setLocalSettings(DEFAULT_PARTICLE_SETTINGS);
    onChange(DEFAULT_PARTICLE_SETTINGS);
  };
  
  return (
    <Card className={cn("bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden", className)}>
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-orange to-neon-blue" />
      <CardContent className="p-6 relative">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-xl font-bold flex items-center text-white">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-neon-orange" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
              <path d="M20.859 10.995a8.965 8.965 0 0 0-9.864-9.864" />
              <circle cx="12" cy="12" r="0" />
            </svg>
            Particle Effects
          </h2>
          {isPremium ? (
            <span className="text-xs bg-neon-orange/20 text-neon-orange px-3 py-1 rounded-full">
              Premium Feature
            </span>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-sm text-white/70">Enable</span>
              <Switch 
                id="particles-enable"
                checked={localSettings.enabled}
                onCheckedChange={(checked) => updateSettings('enabled', checked)}
              />
            </div>
          )}
        </div>
        
        <div className="h-60 relative overflow-hidden rounded-lg mb-6 bg-dark-elevated">
          {/* Particle preview container */}
          <div className="absolute inset-0" id="particle-preview">
            {/* Particle preview will be rendered here via ParticleSystem component */}
          </div>
          
          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-3 z-10">
            <Button 
              variant="outline" 
              size="sm"
              className={cn(
                "px-4 py-2 text-white/90 hover:text-white border shadow-lg text-sm",
                localSettings.type === "fireflies" 
                  ? "border-neon-blue/50 bg-dark-surface/80 backdrop-blur-md shadow-neon-blue/20" 
                  : "bg-dark-surface/40 backdrop-blur-md border-transparent hover:bg-dark-surface/60"
              )}
              onClick={() => handleTypeChange("fireflies")}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
              </svg>
              Fireflies
            </Button>
            
            <Button 
              variant="outline" 
              size="sm"
              className={cn(
                "px-4 py-2 text-white/90 hover:text-white border shadow-lg text-sm",
                localSettings.type === "snow" 
                  ? "border-neon-blue/50 bg-dark-surface/80 backdrop-blur-md shadow-neon-blue/20" 
                  : "bg-dark-surface/40 backdrop-blur-md border-transparent hover:bg-dark-surface/60"
              )}
              onClick={() => handleTypeChange("snow")}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M2 12h20M12 2v20M22 16l-4-4 4-4M16 22l-4-4 4-4M8 6l4 4-4 4M2 8l4 4-4 4" />
              </svg>
              Snow
            </Button>
            
            <Button 
              variant="outline" 
              size="sm"
              className={cn(
                "px-4 py-2 text-white/90 hover:text-white border shadow-lg text-sm",
                localSettings.type === "musicReactive" 
                  ? "border-neon-blue/50 bg-dark-surface/80 backdrop-blur-md shadow-neon-blue/20" 
                  : "bg-dark-surface/40 backdrop-blur-md border-transparent hover:bg-dark-surface/60"
              )}
              onClick={() => handleTypeChange("musicReactive")}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 18V5l12-2v13" />
                <circle cx="6" cy="18" r="3" />
                <circle cx="18" cy="16" r="3" />
              </svg>
              Music Reactive
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-3">
            <div className="flex justify-between text-sm text-white/70 mb-1">
              <span>Particle Density</span>
              <span>
                {localSettings.density < 33 && "Low"}
                {localSettings.density >= 33 && localSettings.density < 66 && "Medium"}
                {localSettings.density >= 66 && "High"}
              </span>
            </div>
            <Slider 
              defaultValue={[localSettings.density]}
              value={[localSettings.density]}
              min={0} 
              max={100} 
              step={1}
              onValueChange={(value) => updateSettings('density', value[0])}
              className="w-full"
            />
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between text-sm text-white/70 mb-1">
              <span>Particle Size</span>
              <span>
                {localSettings.size < 33 && "Small"}
                {localSettings.size >= 33 && localSettings.size < 66 && "Medium"}
                {localSettings.size >= 66 && "Large"}
              </span>
            </div>
            <Slider 
              defaultValue={[localSettings.size]}
              value={[localSettings.size]}
              min={0} 
              max={100} 
              step={1}
              onValueChange={(value) => updateSettings('size', value[0])}
              className="w-full"
            />
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between text-sm text-white/70 mb-1">
              <span>Animation Speed</span>
              <span>
                {localSettings.speed < 33 && "Slow"}
                {localSettings.speed >= 33 && localSettings.speed < 66 && "Medium"}
                {localSettings.speed >= 66 && "Fast"}
              </span>
            </div>
            <Slider 
              defaultValue={[localSettings.speed]}
              value={[localSettings.speed]}
              min={0} 
              max={100} 
              step={1}
              onValueChange={(value) => updateSettings('speed', value[0])}
              className="w-full"
            />
          </div>
        </div>
        
        <div className="mt-6 flex justify-end">
          <Button 
            variant="outline"
            className="bg-neon-orange/20 hover:bg-neon-orange/30 text-white border-none shadow-lg shadow-neon-orange/10 text-sm"
            onClick={handleReset}
          >
            Reset to Default
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default ParticleSettings;
