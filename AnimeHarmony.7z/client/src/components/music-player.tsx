import { useState, useRef, useEffect } from "react";
import ReactPlayer from "react-player/lazy";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useAudio } from "@/hooks/use-audio";
import { useVisualizerStore } from "@/hooks/use-visualizer";
import { Track } from "@shared/schema";
import { formatTime, getYoutubeId } from "@/lib/utils";

interface MusicPlayerProps {
  currentTrack: Track | null;
  onChange: (track: Track | null) => void;
}

export function MusicPlayer({ currentTrack, onChange }: MusicPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(0.75);
  const [isMuted, setIsMuted] = useState(false);
  const [duration, setDuration] = useState(0);
  const [isShuffling, setIsShuffling] = useState(false);
  const [isLooping, setIsLooping] = useState(false);
  const playerRef = useRef<ReactPlayer>(null);
  
  const { analyserNode, audioContext, setAudioSource } = useAudio();
  const { setAnalyserNode } = useVisualizerStore();
  
  // Pass analyser node to visualizer store when it's available
  useEffect(() => {
    if (analyserNode) {
      setAnalyserNode(analyserNode);
    }
  }, [analyserNode, setAnalyserNode]);
  
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };
  
  const handleProgress = (state: { played: number; playedSeconds: number; loaded: number; loadedSeconds: number }) => {
    setProgress(state.playedSeconds);
  };
  
  const handleDuration = (duration: number) => {
    setDuration(duration);
  };
  
  const handleSeek = (value: number[]) => {
    setProgress(value[0]);
    if (playerRef.current) {
      playerRef.current.seekTo(value[0]);
    }
  };
  
  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0] / 100);
    setIsMuted(value[0] === 0);
  };
  
  const handleMuteToggle = () => {
    setIsMuted(!isMuted);
  };
  
  const handleNext = () => {
    // Logic to play next track would go here
    console.log("Next track");
  };
  
  const handlePrevious = () => {
    // Logic to play previous track would go here
    console.log("Previous track");
  };
  
  const toggleShuffle = () => {
    setIsShuffling(!isShuffling);
  };
  
  const toggleLoop = () => {
    setIsLooping(!isLooping);
  };
  
  // Connect audio from ReactPlayer to analyzer node
  const handleReady = () => {
    if (playerRef.current && audioContext) {
      const player = playerRef.current.getInternalPlayer() as HTMLVideoElement | HTMLAudioElement;
      if (player && player instanceof HTMLMediaElement) {
        // Only set up audio source if we don't already have one
        if (!analyserNode) {
          setAudioSource(player);
        }
      }
    }
  };
  
  // Determine media URL and player config based on track source
  const getPlayerConfig = () => {
    if (!currentTrack) return { url: null, config: {} };
    
    let url;
    let config = {};
    
    switch (currentTrack.source) {
      case 'youtube':
        url = currentTrack.sourceUrl;
        config = {
          youtube: {
            playerVars: { 
              controls: 0,
              modestbranding: 1,
              showinfo: 0,
              rel: 0,
              iv_load_policy: 3
            }
          }
        };
        break;
      case 'local':
        url = currentTrack.sourceUrl;
        break;
      default:
        url = currentTrack.sourceUrl;
    }
    
    return { url, config };
  };
  
  const { url, config } = getPlayerConfig();
  
  return (
    <footer className="bg-dark-elevated border-t border-white/10 z-40 px-3 py-3 md:px-6 md:py-4">
      <div className="flex flex-col md:flex-row items-center">
        <div className="flex items-center mb-3 md:mb-0 md:w-1/4">
          {currentTrack && (
            <>
              <div className="w-12 h-12 rounded-md overflow-hidden flex-shrink-0 mr-3">
                <img 
                  src={currentTrack.coverUrl || (currentTrack.source === 'youtube' ? `https://img.youtube.com/vi/${getYoutubeId(currentTrack.sourceUrl)}/0.jpg` : '')} 
                  alt="Now playing" 
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="mr-4">
                <div className="font-medium text-sm">{currentTrack.title}</div>
                <div className="text-white/60 text-xs">{currentTrack.artist || 'Unknown Artist'}</div>
              </div>
              
              <button className="text-white/60 hover:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                </svg>
              </button>
            </>
          )}
          
          {!currentTrack && (
            <div className="text-white/60 text-sm">No track selected</div>
          )}
        </div>
        
        <div className="flex flex-col items-center mb-3 md:mb-0 md:flex-grow">
          <div className="flex items-center gap-5 mb-1">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={`text-white/70 hover:text-white hover:bg-transparent ${isShuffling ? 'text-neon-blue' : ''}`}
                    onClick={toggleShuffle}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="16 3 21 3 21 8" />
                      <line x1="4" y1="20" x2="21" y2="3" />
                      <polyline points="21 16 21 21 16 21" />
                      <line x1="15" y1="15" x2="21" y2="21" />
                      <line x1="4" y1="4" x2="9" y2="9" />
                    </svg>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Shuffle</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-white/70 hover:text-white hover:bg-transparent"
                    onClick={handlePrevious}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polygon points="19 20 9 12 19 4 19 20" />
                      <line x1="5" y1="19" x2="5" y2="5" />
                    </svg>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Previous</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <Button 
              variant="default" 
              size="icon" 
              className="bg-white hover:bg-white/90 text-dark-base h-9 w-9 rounded-full flex items-center justify-center shadow-lg"
              onClick={handlePlayPause}
            >
              {isPlaying ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="6" y="4" width="4" height="16" />
                  <rect x="14" y="4" width="4" height="16" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
              )}
            </Button>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-white/70 hover:text-white hover:bg-transparent"
                    onClick={handleNext}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polygon points="5 4 15 12 5 20 5 4" />
                      <line x1="19" y1="5" x2="19" y2="19" />
                    </svg>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Next</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={`text-white/70 hover:text-white hover:bg-transparent ${isLooping ? 'text-neon-blue' : ''}`}
                    onClick={toggleLoop}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="17 1 21 5 17 9" />
                      <path d="M3 11V9a4 4 0 0 1 4-4h14" />
                      <polyline points="7 23 3 19 7 15" />
                      <path d="M21 13v2a4 4 0 0 1-4 4H3" />
                    </svg>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Loop</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          
          <div className="flex items-center w-full max-w-lg gap-3">
            <span className="text-xs text-white/60">{formatTime(progress)}</span>
            <Slider 
              defaultValue={[0]} 
              value={[progress]} 
              max={duration} 
              step={0.1} 
              onValueChange={handleSeek}
              className="flex-grow h-1"
            />
            <span className="text-xs text-white/60">{formatTime(duration)}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4 md:w-1/4 justify-end">
          <Button 
            variant="ghost" 
            size="icon"
            className="text-white/70 hover:text-white hover:bg-transparent"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="8" y1="6" x2="21" y2="6" />
              <line x1="8" y1="12" x2="21" y2="12" />
              <line x1="8" y1="18" x2="21" y2="18" />
              <line x1="3" y1="6" x2="3.01" y2="6" />
              <line x1="3" y1="12" x2="3.01" y2="12" />
              <line x1="3" y1="18" x2="3.01" y2="18" />
            </svg>
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon"
            className="text-white/70 hover:text-white hover:bg-transparent"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
              <line x1="8" y1="21" x2="16" y2="21" />
              <line x1="12" y1="17" x2="12" y2="21" />
            </svg>
          </Button>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-white/70 hover:text-white hover:bg-transparent"
              onClick={handleMuteToggle}
            >
              {isMuted || volume === 0 ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                  <line x1="23" y1="9" x2="17" y2="15" />
                  <line x1="17" y1="9" x2="23" y2="15" />
                </svg>
              ) : volume < 0.5 ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                  <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                  <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
                  <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
                </svg>
              )}
            </Button>
            <Slider 
              defaultValue={[75]} 
              value={[volume * 100]} 
              max={100} 
              step={1}
              onValueChange={handleVolumeChange}
              className="w-20 h-1"
            />
          </div>
        </div>
      </div>
      
      {/* Hidden player */}
      <div className="hidden">
        <ReactPlayer
          ref={playerRef}
          url={url}
          playing={isPlaying}
          volume={isMuted ? 0 : volume}
          loop={isLooping}
          onProgress={handleProgress}
          onDuration={handleDuration}
          onReady={handleReady}
          onError={(e) => console.error("Player error:", e)}
          width="0"
          height="0"
          config={config}
        />
      </div>
    </footer>
  );
}

export default MusicPlayer;
