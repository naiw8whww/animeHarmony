import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { 
  VisualizerType, 
  ColorStyle, 
  DEFAULT_VISUALIZER_SETTINGS 
} from "@shared/schema";

interface VisualizerSettingsProps {
  settings: typeof DEFAULT_VISUALIZER_SETTINGS;
  onChange: (settings: typeof DEFAULT_VISUALIZER_SETTINGS) => void;
  className?: string;
}

export function VisualizerSettings({
  settings,
  onChange,
  className
}: VisualizerSettingsProps) {
  const [localSettings, setLocalSettings] = useState(settings);
  
  const updateSettings = (key: keyof typeof settings, value: any) => {
    const newSettings = { ...localSettings, [key]: value };
    setLocalSettings(newSettings);
    onChange(newSettings);
  };
  
  const handleTypeChange = (type: VisualizerType) => {
    updateSettings('type', type);
  };
  
  const handleColorStyleChange = (style: ColorStyle) => {
    updateSettings('colorStyle', style);
  };
  
  const handleReset = () => {
    setLocalSettings(DEFAULT_VISUALIZER_SETTINGS);
    onChange(DEFAULT_VISUALIZER_SETTINGS);
  };
  
  return (
    <div className={cn("space-y-6", className)}>
      <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
        <CardContent className="p-5 relative">
          <h3 className="font-semibold mb-3 flex items-center text-white">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-neon-blue" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 22h14a2 2 0 0 0 2-2V7.5L14.5 2H6a2 2 0 0 0-2 2v4" />
              <polyline points="14 2 14 8 20 8" />
              <path d="M2 15h10" />
              <path d="M9 18l3-3-3-3" />
            </svg>
            Visualizer Style
          </h3>
          
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div 
              className={cn(
                "bg-dark-elevated p-2 rounded-md text-center text-sm border transition-all cursor-pointer",
                localSettings.type === "bars" 
                  ? "text-white/90 border-neon-blue" 
                  : "text-white/70 hover:text-white/90 border-transparent hover:border-white/20"
              )}
              onClick={() => handleTypeChange("bars")}
            >
              <div className="h-10 flex items-end justify-center space-x-1 mb-2">
                <div className="w-1 h-6 bg-gradient-to-t from-neon-blue to-neon-pink rounded-t"></div>
                <div className="w-1 h-9 bg-gradient-to-t from-neon-blue to-neon-pink rounded-t"></div>
                <div className="w-1 h-4 bg-gradient-to-t from-neon-blue to-neon-pink rounded-t"></div>
              </div>
              Bars
            </div>
            
            <div
              className={cn(
                "bg-dark-elevated p-2 rounded-md text-center text-sm border transition-all cursor-pointer",
                localSettings.type === "circular" 
                  ? "text-white/90 border-neon-blue" 
                  : "text-white/70 hover:text-white/90 border-transparent hover:border-white/20"
              )}
              onClick={() => handleTypeChange("circular")}
            >
              <div className="h-10 flex items-center justify-center mb-2">
                <div className="w-10 h-10 bg-neon-blue/20 rounded-full flex items-center justify-center">
                  <div className="w-6 h-6 bg-neon-blue/40 rounded-full flex items-center justify-center">
                    <div className="w-3 h-3 bg-neon-blue rounded-full"></div>
                  </div>
                </div>
              </div>
              Circular
            </div>
            
            <div
              className={cn(
                "bg-dark-elevated p-2 rounded-md text-center text-sm border transition-all cursor-pointer",
                localSettings.type === "wave" 
                  ? "text-white/90 border-neon-blue" 
                  : "text-white/70 hover:text-white/90 border-transparent hover:border-white/20"
              )}
              onClick={() => handleTypeChange("wave")}
            >
              <div className="h-10 flex items-center justify-center mb-2">
                <div className="w-10 h-8 flex">
                  <div className="w-1/3 h-full bg-gradient-to-br from-neon-blue to-neon-pink opacity-40"></div>
                  <div className="w-1/3 h-full bg-gradient-to-br from-neon-blue to-neon-pink opacity-70"></div>
                  <div className="w-1/3 h-full bg-gradient-to-br from-neon-blue to-neon-pink"></div>
                </div>
              </div>
              Wave
            </div>
          </div>
          
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm text-white/70 mb-1">
                <span>Sensitivity</span>
                <span>{localSettings.sensitivity}%</span>
              </div>
              <Slider 
                defaultValue={[localSettings.sensitivity]}
                value={[localSettings.sensitivity]}
                min={0} 
                max={100} 
                step={1}
                onValueChange={(value) => updateSettings('sensitivity', value[0])}
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm text-white/70 mb-1">
                <span>Bar Count</span>
                <span>{localSettings.barCount}</span>
              </div>
              <Slider 
                defaultValue={[localSettings.barCount]}
                value={[localSettings.barCount]}
                min={10} 
                max={100} 
                step={1}
                onValueChange={(value) => updateSettings('barCount', value[0])}
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm text-white/70 mb-1">
                <span>Animation Speed</span>
                <span>
                  {localSettings.animationSpeed < 33 && "Slow"}
                  {localSettings.animationSpeed >= 33 && localSettings.animationSpeed < 66 && "Medium"}
                  {localSettings.animationSpeed >= 66 && "Fast"}
                </span>
              </div>
              <Slider 
                defaultValue={[localSettings.animationSpeed]}
                value={[localSettings.animationSpeed]}
                min={0} 
                max={100} 
                step={1}
                onValueChange={(value) => updateSettings('animationSpeed', value[0])}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-pink to-neon-orange" />
        <CardContent className="p-5 relative">
          <h3 className="font-semibold mb-3 flex items-center text-white">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-neon-pink" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="13.5" cy="6.5" r="3.5"/>
              <circle cx="7" cy="17" r="4"/>
              <circle cx="18" cy="16" r="3"/>
            </svg>
            Color Style
          </h3>
          
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div
              className={cn(
                "bg-dark-elevated p-2 rounded-md text-center text-sm border transition-all cursor-pointer",
                localSettings.colorStyle === "gradient" 
                  ? "text-white/90 border-neon-pink" 
                  : "text-white/70 hover:text-white/90 border-transparent hover:border-white/20"
              )}
              onClick={() => handleColorStyleChange("gradient")}
            >
              <div className="h-10 flex justify-center items-end space-x-1 mb-2">
                <div className="w-1 h-6 bg-gradient-to-t from-neon-blue to-neon-pink rounded-t"></div>
                <div className="w-1 h-9 bg-gradient-to-t from-neon-blue to-neon-pink rounded-t"></div>
                <div className="w-1 h-4 bg-gradient-to-t from-neon-blue to-neon-pink rounded-t"></div>
              </div>
              Gradient
            </div>
            
            <div
              className={cn(
                "bg-dark-elevated p-2 rounded-md text-center text-sm border transition-all cursor-pointer",
                localSettings.colorStyle === "spectrum" 
                  ? "text-white/90 border-neon-pink" 
                  : "text-white/70 hover:text-white/90 border-transparent hover:border-white/20"
              )}
              onClick={() => handleColorStyleChange("spectrum")}
            >
              <div className="h-10 flex justify-center items-end space-x-1 mb-2">
                <div className="w-1 h-6 bg-neon-blue rounded-t"></div>
                <div className="w-1 h-9 bg-neon-pink rounded-t"></div>
                <div className="w-1 h-4 bg-neon-orange rounded-t"></div>
              </div>
              Spectrum
            </div>
            
            <div
              className={cn(
                "bg-dark-elevated p-2 rounded-md text-center text-sm border transition-all cursor-pointer",
                localSettings.colorStyle === "solid" 
                  ? "text-white/90 border-neon-pink" 
                  : "text-white/70 hover:text-white/90 border-transparent hover:border-white/20"
              )}
              onClick={() => handleColorStyleChange("solid")}
            >
              <div className="h-10 flex justify-center items-end space-x-1 mb-2">
                <div className="w-1 h-6 bg-white rounded-t"></div>
                <div className="w-1 h-9 bg-white rounded-t"></div>
                <div className="w-1 h-4 bg-white rounded-t"></div>
              </div>
              Solid
            </div>
          </div>
          
          <div className="grid grid-cols-5 gap-2 mb-4">
            <button className="w-full h-8 rounded-md bg-gradient-to-r from-neon-blue to-neon-pink"></button>
            <button className="w-full h-8 rounded-md bg-gradient-to-r from-purple-500 to-pink-500"></button>
            <button className="w-full h-8 rounded-md bg-gradient-to-r from-green-400 to-blue-500"></button>
            <button className="w-full h-8 rounded-md bg-gradient-to-r from-red-500 to-yellow-500"></button>
            <button className="w-full h-8 rounded-md border border-dashed border-white/30 flex items-center justify-center text-white/70">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
            </button>
          </div>
          
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm text-white/70 mb-1">
                <span>Color Intensity</span>
                <span>{localSettings.colorIntensity}%</span>
              </div>
              <Slider 
                defaultValue={[localSettings.colorIntensity]}
                value={[localSettings.colorIntensity]}
                min={0} 
                max={100} 
                step={1}
                onValueChange={(value) => updateSettings('colorIntensity', value[0])}
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm text-white/70 mb-1">
                <span>Glow Effect</span>
                <span>{localSettings.glowEffect ? "On" : "Off"}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Switch 
                  id="glow-effect"
                  checked={localSettings.glowEffect}
                  onCheckedChange={(checked) => updateSettings('glowEffect', checked)}
                />
                <Label htmlFor="glow-effect" className="text-white/70">Toggle effect</Label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-orange to-neon-blue" />
        <CardContent className="p-5 relative">
          <h3 className="font-semibold mb-3 flex items-center text-white">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-neon-orange" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
            </svg>
            Advanced Options
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/80">Edge Smoothing</span>
              <Switch 
                id="edge-smoothing"
                checked={localSettings.edgeSmoothing}
                onCheckedChange={(checked) => updateSettings('edgeSmoothing', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/80">Mirror Effect</span>
              <Switch 
                id="mirror-effect"
                checked={localSettings.mirrorEffect}
                onCheckedChange={(checked) => updateSettings('mirrorEffect', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/80">Reactive Background</span>
              <Switch 
                id="reactive-bg"
                checked={localSettings.reactiveBackground}
                onCheckedChange={(checked) => updateSettings('reactiveBackground', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/80">Beat Detection</span>
              <Switch 
                id="beat-detection"
                checked={localSettings.beatDetection}
                onCheckedChange={(checked) => updateSettings('beatDetection', checked)}
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm text-white/70 mb-1">
                <span>Frequency Response</span>
                <span>
                  {localSettings.frequencyResponse < 33 && "Bass-heavy"}
                  {localSettings.frequencyResponse >= 33 && localSettings.frequencyResponse < 66 && "Balanced"}
                  {localSettings.frequencyResponse >= 66 && "Treble-focused"}
                </span>
              </div>
              <Slider 
                defaultValue={[localSettings.frequencyResponse]}
                value={[localSettings.frequencyResponse]}
                min={0} 
                max={100} 
                step={1}
                onValueChange={(value) => updateSettings('frequencyResponse', value[0])}
              />
            </div>
            
            <div>
              <Button 
                className="w-full bg-neon-orange/20 hover:bg-neon-orange/30 text-white shadow-lg shadow-neon-orange/10 text-sm"
                onClick={handleReset}
              >
                Reset to Default
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default VisualizerSettings;
