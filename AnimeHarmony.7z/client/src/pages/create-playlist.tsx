import { useState } from "react";
import { useLocation } from "wouter";
import { MainLayout } from "@/components/layouts/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { ParticleSystem } from "@/components/ui/particle-system";
import { useAudio } from "@/hooks/use-audio";
import { useParticleStore } from "@/hooks/use-particles";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export function CreatePlaylist() {
  const [playlistName, setPlaylistName] = useState("");
  const [playlistDescription, setPlaylistDescription] = useState("");
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [_, setLocation] = useLocation();
  const { audioData } = useAudio();
  const particleSettings = useParticleStore((state) => state.settings);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Create playlist mutation
  const createPlaylistMutation = useMutation({
    mutationFn: async (data: { name: string; description: string; coverUrl: string }) => {
      const response = await apiRequest('POST', '/api/playlists', {
        ...data,
        userId: 1, // In a real app, this would be the current user's ID
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/playlists'] });
      toast({
        title: "Playlist created",
        description: "Your new playlist has been created successfully.",
      });
      setLocation(`/playlist/${data.id}`);
    },
    onError: (error) => {
      toast({
        title: "Failed to create playlist",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setCoverFile(file);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    let coverUrl = "https://images.unsplash.com/photo-1565098772267-60af42b81ef2";
    
    // In a real app, we would upload the cover image to a server
    // For now, we'll use the preview URL if available, or default cover
    if (previewUrl) {
      coverUrl = previewUrl;
    }
    
    createPlaylistMutation.mutate({
      name: playlistName,
      description: playlistDescription,
      coverUrl,
    });
  };
  
  return (
    <MainLayout>
      {/* Particle effects */}
      {particleSettings.enabled && (
        <ParticleSystem 
          type={particleSettings.type}
          density={particleSettings.density}
          size={particleSettings.size}
          speed={particleSettings.speed}
          audioData={audioData || undefined}
        />
      )}
      
      <div className="p-4 md:p-8">
        <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden max-w-2xl mx-auto">
          <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
          <CardContent className="p-6">
            <h1 className="text-3xl font-bold mb-6">
              Create New <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">Playlist</span>
            </h1>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <div className="space-y-2 mb-4">
                    <Label htmlFor="playlist-name">Playlist Name</Label>
                    <Input 
                      id="playlist-name"
                      value={playlistName}
                      onChange={(e) => setPlaylistName(e.target.value)}
                      placeholder="My Awesome Playlist"
                      className="bg-dark-elevated border-none text-white"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="playlist-description">Description (optional)</Label>
                    <Input 
                      id="playlist-description"
                      value={playlistDescription}
                      onChange={(e) => setPlaylistDescription(e.target.value)}
                      placeholder="A collection of my favorite tracks"
                      className="bg-dark-elevated border-none text-white"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="cover-upload" className="mb-2 block">Cover Image (optional)</Label>
                  <div className="aspect-square rounded-lg overflow-hidden bg-dark-elevated mb-3 relative">
                    {previewUrl ? (
                      <img 
                        src={previewUrl} 
                        alt="Cover preview" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white/20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                          <circle cx="8.5" cy="8.5" r="1.5" />
                          <polyline points="21 15 16 10 5 21" />
                        </svg>
                      </div>
                    )}
                    
                    <Input 
                      id="cover-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleCoverChange}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    
                    <div className="absolute bottom-2 right-2">
                      <Button 
                        type="button" 
                        className="bg-dark-base/80 backdrop-blur-sm hover:bg-dark-base/90 text-white text-sm h-8 w-8 p-0 rounded-full"
                        onClick={() => document.getElementById('cover-upload')?.click()}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          {previewUrl ? (
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                          ) : (
                            <path d="M12 5v14M5 12h14" />
                          )}
                        </svg>
                      </Button>
                    </div>
                  </div>
                  <p className="text-white/60 text-sm">Click or drag image to upload a cover</p>
                </div>
              </div>
              
              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="bg-dark-elevated/50 hover:bg-dark-elevated border-none text-white"
                  onClick={() => window.history.back()}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="bg-gradient-to-r from-neon-blue to-neon-pink hover:opacity-90"
                  disabled={createPlaylistMutation.isPending}
                >
                  {createPlaylistMutation.isPending ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Creating...
                    </>
                  ) : (
                    "Create Playlist"
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

export default CreatePlaylist;
