import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { MainLayout } from "@/components/layouts/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ParticleSystem } from "@/components/ui/particle-system";
import { useAudio } from "@/hooks/use-audio";
import { useParticleStore } from "@/hooks/use-particles";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Track, PlaylistTrack } from "@shared/schema";
import { formatTime } from "@/lib/utils";

export function PlaylistDetail() {
  const [_, params] = useRoute<{ id: string }>("/playlist/:id");
  const playlistId = params?.id ? parseInt(params.id) : null;
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [playlistName, setPlaylistName] = useState("");
  const [playlistDescription, setPlaylistDescription] = useState("");
  const { audioData } = useAudio();
  const particleSettings = useParticleStore((state) => state.settings);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch playlist details
  const { data: playlist, isLoading: isLoadingPlaylist } = useQuery({
    queryKey: [`/api/playlists/${playlistId}`],
    enabled: !!playlistId,
  });
  
  // Set form values when playlist data loads
  useEffect(() => {
    if (playlist) {
      setPlaylistName(playlist.name);
      setPlaylistDescription(playlist.description || "");
    }
  }, [playlist]);
  
  // Update playlist mutation
  const updatePlaylistMutation = useMutation({
    mutationFn: async (data: { name: string; description: string }) => {
      const response = await apiRequest('PATCH', `/api/playlists/${playlistId}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/playlists/${playlistId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/playlists'] });
      setIsEditModalOpen(false);
      toast({
        title: "Playlist updated",
        description: "Your changes have been saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update playlist",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  // Remove track from playlist mutation
  const removeTrackMutation = useMutation({
    mutationFn: async (trackId: number) => {
      await apiRequest('DELETE', `/api/playlists/${playlistId}/tracks/${trackId}`);
      return trackId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/playlists/${playlistId}`] });
      toast({
        title: "Track removed",
        description: "The track has been removed from the playlist.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to remove track",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  const handleUpdatePlaylist = (e: React.FormEvent) => {
    e.preventDefault();
    updatePlaylistMutation.mutate({
      name: playlistName,
      description: playlistDescription,
    });
  };
  
  const handleRemoveTrack = (trackId: number) => {
    if (confirm("Are you sure you want to remove this track from the playlist?")) {
      removeTrackMutation.mutate(trackId);
    }
  };
  
  const handlePlayTrack = (track: Track) => {
    // In a real implementation, this would start playing the track
    console.log("Playing track:", track);
  };
  
  // Calculate total duration
  const getTotalDuration = () => {
    if (!playlist?.tracks) return 0;
    return playlist.tracks.reduce((total, track) => total + (track.duration || 0), 0);
  };
  
  return (
    <MainLayout>
      {/* Particle effects */}
      {particleSettings.enabled && (
        <ParticleSystem 
          type={particleSettings.type}
          density={particleSettings.density}
          size={particleSettings.size}
          speed={particleSettings.speed}
          audioData={audioData || undefined}
        />
      )}
      
      <div className="p-4 md:p-8">
        {isLoadingPlaylist ? (
          <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg animate-pulse">
            <CardContent className="p-6">
              <div className="h-8 bg-dark-elevated/50 rounded w-1/3 mb-4"></div>
              <div className="h-4 bg-dark-elevated/50 rounded w-1/4 mb-8"></div>
              <div className="grid md:grid-cols-5 gap-6">
                <div className="md:col-span-2">
                  <div className="h-64 bg-dark-elevated/50 rounded mb-4"></div>
                  <div className="h-6 bg-dark-elevated/50 rounded w-full mb-2"></div>
                  <div className="h-4 bg-dark-elevated/50 rounded w-2/3"></div>
                </div>
                <div className="md:col-span-3">
                  <div className="h-8 bg-dark-elevated/50 rounded w-1/4 mb-4"></div>
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="h-16 bg-dark-elevated/50 rounded mb-2"></div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ) : playlist ? (
          <>
            {/* Playlist header */}
            <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden mb-8">
              <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
              <CardContent className="p-6">
                <div className="grid md:grid-cols-5 gap-6">
                  <div className="md:col-span-2">
                    <div className="aspect-square max-w-sm rounded-lg overflow-hidden shadow-lg mb-4">
                      <img 
                        src={playlist.coverUrl || "https://images.unsplash.com/photo-1565098772267-60af42b81ef2"} 
                        alt={playlist.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    <h1 className="text-3xl font-bold mb-2">{playlist.name}</h1>
                    <p className="text-white/70 mb-4">{playlist.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      <Badge variant="outline" className="bg-neon-blue/20 text-white border-none">
                        {playlist.tracks?.length || 0} tracks
                      </Badge>
                      <Badge variant="outline" className="bg-neon-pink/20 text-white border-none">
                        {formatTime(getTotalDuration())} total
                      </Badge>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      <Button className="bg-neon-pink hover:bg-neon-pink/90 text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <polygon points="5 3 19 12 5 21 5 3"></polygon>
                        </svg>
                        Play All
                      </Button>
                      
                      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="bg-dark-elevated/50 hover:bg-dark-elevated border-none text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Edit Playlist
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-dark-surface/90 backdrop-blur-md border-none text-white">
                          <DialogHeader>
                            <DialogTitle>Edit Playlist</DialogTitle>
                          </DialogHeader>
                          <form onSubmit={handleUpdatePlaylist} className="space-y-4 pt-4">
                            <div className="space-y-2">
                              <Label htmlFor="name">Playlist Name</Label>
                              <Input 
                                id="name" 
                                value={playlistName}
                                onChange={(e) => setPlaylistName(e.target.value)}
                                className="bg-dark-elevated border-none text-white"
                                required
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="description">Description</Label>
                              <Input 
                                id="description" 
                                value={playlistDescription}
                                onChange={(e) => setPlaylistDescription(e.target.value)}
                                className="bg-dark-elevated border-none text-white"
                              />
                            </div>
                            <div className="flex justify-end gap-2 pt-2">
                              <Button type="button" variant="outline" onClick={() => setIsEditModalOpen(false)} className="bg-dark-elevated/50 hover:bg-dark-elevated border-none text-white">
                                Cancel
                              </Button>
                              <Button type="submit" className="bg-neon-blue hover:bg-neon-blue/90">
                                Save Changes
                              </Button>
                            </div>
                          </form>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                  
                  <div className="md:col-span-3">
                    <h2 className="text-xl font-bold mb-4">Tracks</h2>
                    
                    {playlist.tracks && playlist.tracks.length > 0 ? (
                      <div className="space-y-2">
                        {playlist.tracks.map((track: PlaylistTrack & Track, index: number) => (
                          <Card key={track.id} className="bg-dark-elevated/50 hover:bg-dark-elevated/80 border-none transition-colors">
                            <CardContent className="p-3 flex items-center gap-3">
                              <div className="w-8 h-8 flex items-center justify-center text-white/50">
                                {index + 1}
                              </div>
                              <div className="w-10 h-10 rounded overflow-hidden bg-dark-elevated flex-shrink-0">
                                {track.coverUrl && (
                                  <img 
                                    src={track.coverUrl} 
                                    alt={track.title} 
                                    className="w-full h-full object-cover"
                                  />
                                )}
                              </div>
                              <div className="flex-grow min-w-0">
                                <div className="font-medium truncate">{track.title}</div>
                                <div className="text-white/60 text-sm truncate">{track.artist || "Unknown Artist"}</div>
                              </div>
                              <div className="text-white/60 text-sm">
                                {formatTime(track.duration || 0)}
                              </div>
                              <div className="flex gap-1">
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="text-white/70 hover:text-white hover:bg-white/10 h-8 w-8"
                                  onClick={() => handlePlayTrack(track)}
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <polygon points="5 3 19 12 5 21 5 3"></polygon>
                                  </svg>
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="text-white/70 hover:text-red-500 hover:bg-white/10 h-8 w-8"
                                  onClick={() => handleRemoveTrack(track.trackId)}
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <path d="M3 6h18"></path>
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"></path>
                                    <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                  </svg>
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <Card className="bg-dark-elevated/30 border-none">
                        <CardContent className="p-6 text-center">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-white/20 mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                          </svg>
                          <h3 className="text-lg font-medium mb-2">No tracks in this playlist</h3>
                          <p className="text-white/60 mb-4">Add tracks from the library or search for music to add.</p>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        ) : (
          <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg">
            <CardContent className="p-6 text-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-white/20 mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              <h2 className="text-xl font-bold mb-2">Playlist Not Found</h2>
              <p className="text-white/70 mb-6">The playlist you're looking for doesn't exist or has been removed.</p>
              <Button 
                className="bg-neon-blue hover:bg-neon-blue/90"
                onClick={() => window.history.back()}
              >
                Go Back
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}

export default PlaylistDetail;
